package convertTest;

import java.security.PublicKey;

public class businesspo {
  public String equiName;
    public  String location;

    @Override
    public String toString() {
        return  "equiName"+equiName+";"+"location"+location;
    }
}
