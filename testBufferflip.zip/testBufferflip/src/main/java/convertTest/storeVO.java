package convertTest;

public class storeVO {
    String name;
    String attri;
}
