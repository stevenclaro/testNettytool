package IOT;

public class equipModel {

/*
    public String TagID;//监控点编号
    public String TagName;//监控点名称
    public String TagDesc;//监控点描述
    public String TagLocation;//监控点位置
    public int DataType;//监控点数据类型 1：开关型（返回1 或0）2：整型（最大64 位）3：浮点型（最大64 位）4：字符型（最大128 个字符）
    public int AccessRight;//1：只读，2：读写
    public String Unit;//监控点单位
    public double MinValue;//监控点最小值
    public double MaxValue;//监控点最大值*/
}
