package IOT;

public class airCondition {
    public TagInfo 风流状态;
    public TagInfo 回风温度;

    //每个设备类型，单独的设置一个静态类，是不可行的。主要是静态类太多了。
    //主要考虑采用代码层面来进行处理。

}
