package excel;

public class rowdata {
    public String CodeAll;
    public String no1;
    public String no2;
    public String no3;
    public String no4;
    public String no5;

}
